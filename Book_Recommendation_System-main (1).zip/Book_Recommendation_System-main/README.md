# Book_Recommendation_System
# To run :  $ streamlit run app.py
### Project Demo  Video:
https://youtu.be/UOUqlZVNLdE

More example Input: Algorithms, The Information: A History, Unity in Action

### Limitations: It only support programming books recomendation from its list of books.
